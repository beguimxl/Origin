package com.example.grade

import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.view.View
import com.example.myapplication.R

import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var java = 0
        var net = 0
        var database = 0

        var total = 0
        var ave = 0

        java = editTextJava.text.toString().toInt()
        net = editTextNetwork.text.toString().toInt()
        database = editTextDatabase.text.toString().toInt()


        buttonTotal.setOnClickListener {
            total = java + net + database
            tvTotal.text = total.toString()
        }

        buttonAve.setOnClickListener {
            ave = total / 3
            tvAve.text = ave.toString()

        }
    }}